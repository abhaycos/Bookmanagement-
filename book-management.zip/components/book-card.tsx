"use client"

import type { Book } from "@/types/book"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Edit, Trash2, BookOpen, Calendar, User, Star } from "lucide-react"

type BookCardProps = {
  book: Book
  onEdit: () => void
  onDelete: () => void
}

export function BookCard({ book, onEdit, onDelete }: BookCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-start justify-between">
          <div className="truncate">{book.title}</div>
          <div className="flex items-center text-amber-500">
            <Star className="h-4 w-4 fill-current mr-1" />
            <span>{book.rating}</span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="flex items-center text-sm">
          <User className="h-4 w-4 mr-2 opacity-70" />
          <span>{book.author}</span>
        </div>
        <div className="flex items-center text-sm">
          <Calendar className="h-4 w-4 mr-2 opacity-70" />
          <span>{new Date(book.publishedOn).toLocaleDateString()}</span>
        </div>
        <div className="flex items-center text-sm">
          <BookOpen className="h-4 w-4 mr-2 opacity-70" />
          <span>{book.genre}</span>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" size="sm" onClick={onEdit}>
          <Edit className="h-4 w-4 mr-2" />
          Edit
        </Button>
        <Button variant="outline" size="sm" onClick={onDelete}>
          <Trash2 className="h-4 w-4 mr-2" />
          Delete
        </Button>
      </CardFooter>
    </Card>
  )
}
