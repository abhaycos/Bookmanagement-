"use client"

import type { Book } from "@/types/book"
import { BookCard } from "@/components/book-card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Edit, Trash2 } from "lucide-react"

type BookListProps = {
  books: Book[]
  onEdit: (book: Book) => void
  onDelete: (id: string) => void
}

export function BookList({ books, onEdit, onDelete }: BookListProps) {
  if (books.length === 0) {
    return (
      <div className="text-center p-8 border rounded-lg">
        <p className="text-muted-foreground">No books added yet. Add your first book!</p>
      </div>
    )
  }

  return (
    <Tabs defaultValue="table" className="w-full">
      <TabsList className="grid w-full grid-cols-2 mb-4">
        <TabsTrigger value="table">Table View</TabsTrigger>
        <TabsTrigger value="cards">Card View</TabsTrigger>
      </TabsList>

      <TabsContent value="table" className="border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Author</TableHead>
                <TableHead>Published</TableHead>
                <TableHead>Genre</TableHead>
                <TableHead>Rating</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {books.map((book) => (
                <TableRow key={book.id}>
                  <TableCell className="font-medium">{book.title}</TableCell>
                  <TableCell>{book.author}</TableCell>
                  <TableCell>{new Date(book.publishedOn).toLocaleDateString()}</TableCell>
                  <TableCell>{book.genre}</TableCell>
                  <TableCell>{book.rating} / 5</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      <Button variant="ghost" size="icon" onClick={() => onEdit(book)} title="Edit">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => onDelete(book.id)} title="Delete">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </TabsContent>

      <TabsContent value="cards" className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {books.map((book) => (
          <BookCard key={book.id} book={book} onEdit={() => onEdit(book)} onDelete={() => onDelete(book.id)} />
        ))}
      </TabsContent>
    </Tabs>
  )
}
