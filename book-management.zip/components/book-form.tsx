"use client"

import type React from "react"

import { useState, useEffect } from "react"
import type { Book } from "@/types/book"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type BookFormProps = {
  onSubmit: (book: Book | Omit<Book, "id">) => void
  initialData?: Book | null
  onCancel?: () => void
}

const genres = [
  "Fiction",
  "Non-Fiction",
  "Science Fiction",
  "Fantasy",
  "Mystery",
  "Thriller",
  "Romance",
  "Biography",
  "History",
  "Self-Help",
  "Other",
]

export function BookForm({ onSubmit, initialData, onCancel }: BookFormProps) {
  const [formData, setFormData] = useState<Omit<Book, "id">>({
    title: "",
    author: "",
    publishedOn: new Date().toISOString().split("T")[0],
    genre: "Fiction",
    rating: 0,
  })

  // Update form data when initialData changes
  useEffect(() => {
    if (initialData) {
      setFormData({
        title: initialData.title,
        author: initialData.author,
        publishedOn: initialData.publishedOn,
        genre: initialData.genre,
        rating: initialData.rating,
      })
    }
  }, [initialData])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: name === "rating" ? Number.parseFloat(value) : value,
    }))
  }

  const handleGenreChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      genre: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (initialData) {
      onSubmit({ ...formData, id: initialData.id })
    } else {
      onSubmit(formData)
    }

    // Reset form if not editing
    if (!initialData) {
      setFormData({
        title: "",
        author: "",
        publishedOn: new Date().toISOString().split("T")[0],
        genre: "Fiction",
        rating: 0,
      })
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6 border rounded-lg shadow-sm">
      <div className="space-y-2">
        <Label htmlFor="title">Title</Label>
        <Input
          id="title"
          name="title"
          value={formData.title}
          onChange={handleChange}
          placeholder="Enter book title"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="author">Author</Label>
        <Input
          id="author"
          name="author"
          value={formData.author}
          onChange={handleChange}
          placeholder="Enter author name"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="publishedOn">Published On</Label>
        <Input
          id="publishedOn"
          name="publishedOn"
          type="date"
          value={formData.publishedOn}
          onChange={handleChange}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="genre">Genre</Label>
        <Select value={formData.genre} onValueChange={handleGenreChange}>
          <SelectTrigger>
            <SelectValue placeholder="Select genre" />
          </SelectTrigger>
          <SelectContent>
            {genres.map((genre) => (
              <SelectItem key={genre} value={genre}>
                {genre}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="rating">Rating (0-5)</Label>
        <div className="flex items-center space-x-2">
          <Input
            id="rating"
            name="rating"
            type="number"
            min="0"
            max="5"
            step="0.1"
            value={formData.rating}
            onChange={handleChange}
            required
          />
          <span className="text-sm text-muted-foreground">{formData.rating} / 5</span>
        </div>
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
        <Button type="submit">{initialData ? "Update Book" : "Add Book"}</Button>
      </div>
    </form>
  )
}
