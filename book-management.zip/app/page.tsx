"use client"

import { useState, useEffect } from "react"
import { v4 as uuidv4 } from "uuid"
import { BookForm } from "@/components/book-form"
import { BookList } from "@/components/book-list"
import type { Book } from "@/types/book"

export default function Home() {
  const [books, setBooks] = useState<Book[]>([])
  const [bookToEdit, setBookToEdit] = useState<Book | null>(null)

  // Load books from localStorage on initial render
  useEffect(() => {
    const savedBooks = localStorage.getItem("books")
    if (savedBooks) {
      setBooks(JSON.parse(savedBooks))
    }
  }, [])

  // Save books to localStorage whenever books state changes
  useEffect(() => {
    localStorage.setItem("books", JSON.stringify(books))
  }, [books])

  // Create a new book
  const handleCreateBook = (book: Omit<Book, "id">) => {
    const newBook = {
      ...book,
      id: uuidv4(),
    }
    setBooks([...books, newBook])
  }

  // Update an existing book
  const handleUpdateBook = (updatedBook: Book) => {
    setBooks(books.map((book) => (book.id === updatedBook.id ? updatedBook : book)))
    setBookToEdit(null)
  }

  // Delete a book
  const handleDeleteBook = (id: string) => {
    setBooks(books.filter((book) => book.id !== id))
  }

  // Set book to edit
  const handleEditBook = (book: Book) => {
    setBookToEdit(book)
  }

  return (
    <main className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-8 text-center">Book Management System</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-semibold mb-4">{bookToEdit ? "Edit Book" : "Add New Book"}</h2>
          <BookForm
            onSubmit={bookToEdit ? handleUpdateBook : handleCreateBook}
            initialData={bookToEdit}
            onCancel={bookToEdit ? () => setBookToEdit(null) : undefined}
          />
        </div>

        <div>
          <h2 className="text-2xl font-semibold mb-4">Book Collection</h2>
          <BookList books={books} onEdit={handleEditBook} onDelete={handleDeleteBook} />
        </div>
      </div>
    </main>
  )
}
